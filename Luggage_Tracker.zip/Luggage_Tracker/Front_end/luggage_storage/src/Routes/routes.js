import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Logincredentials from "../Pages/Login/index";
import LandingPage from "../Pages/LandingPage";
import Home from "../Pages/Home";
import { ROUTE_CONSTANTS } from "../Constants/routeConstants";
import Luggage from "../Pages/Luggage";
import Signup from "../Pages/Login/Signup";
import Payment from "../Pages/Payments";
import Order from "../Pages/Orders/index";

function Router() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path={ROUTE_CONSTANTS.LANDINGPAGE} element={<LandingPage />}>
          <Route path={ROUTE_CONSTANTS.LOGIN} element={<Logincredentials />} />
          <Route path={ROUTE_CONSTANTS.SIGNUP} element={<Signup />} />
        </Route>
        <Route path={ROUTE_CONSTANTS.HOME} element={<Home />} />
        <Route path={ROUTE_CONSTANTS.LUGGAGE} element={<Luggage />} />
        <Route path={ROUTE_CONSTANTS.PAYMENT} element={<Payment />} />
        <Route path={ROUTE_CONSTANTS.ORDERS} element={<Order />} />
      </Routes>
    </BrowserRouter>
  );
}

export default Router;
