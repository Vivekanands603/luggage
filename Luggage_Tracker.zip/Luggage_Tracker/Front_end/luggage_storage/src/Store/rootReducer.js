import { userService } from "../Service/userService";
import { mainService } from "../Service/mainService";
import { locationService } from "../Service/locationService";

const rootReducer = {
  [userService.reducerPath]: userService.reducer,
  [mainService.reducerPath]: mainService.reducer,
  [locationService.reducerPath]: locationService.reducer,
};

export default rootReducer;
