import { locationService } from "../Service/locationService";
import { mainService } from "../Service/mainService";
import { paymentService } from "../Service/paymentService";
import { userService } from "../Service/userService";

const middleware = [
  userService.middleware,
  mainService.middleware,
  locationService.middleware,
  paymentService.middleware,
];

export default middleware;
