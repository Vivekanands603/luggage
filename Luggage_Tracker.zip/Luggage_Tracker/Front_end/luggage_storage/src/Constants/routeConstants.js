export const ROUTE_CONSTANTS = {
  LANDINGPAGE: "/",
  HOME: "/home",
  LOGIN: "/login",
  SIGNUP: "/signup",
  LUGGAGE: "/luggage",
  PAYMENT: "/payment",
  ORDERS: "/orders",
};
