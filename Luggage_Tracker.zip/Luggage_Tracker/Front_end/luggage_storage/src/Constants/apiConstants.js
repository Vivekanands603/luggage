export const ENDPOINT_CONSTANTS = {
  LOGIN: "/auth/login",
  REGISTER: "/auth/register",
  GET_LUGGAGE: "/main",
  ADD_LUGGAGE: "/main",
  UPDATE_LUGGAGE: "/main",
  DELETE_LUGGAGE: "/main",
  GET_LOCATIONS: "/location",
  ADD_LOCATIONS: "/location",
  ADD_PAYMENTS: "/payment",
  GET_PAYMENTS: "/payment",
};
