export const LOCAL_CONSTANTS = {
  ACCESS: "accessToken",
  REFRESH: "refreshToken",
  USER: "user",
};
