import { createApi } from "@reduxjs/toolkit/query/react";
import baseQueryWithReauth from "./baseQuery";
import { ENDPOINT_CONSTANTS } from "../Constants/apiConstants";

export const paymentService = createApi({
  reducerPath: "paymentService",
  baseQuery: baseQueryWithReauth,
  endpoints: (builder) => ({
    addPayment: builder.mutation({
      query: (payload) => ({
        url: ENDPOINT_CONSTANTS.ADD_PAYMENTS,
        method: "POST",
        body: payload,
      }),
    }),
    getPayment: builder.query({
      query: () => ({
        url: ENDPOINT_CONSTANTS.GET_PAYMENTS,
        method: "GET",
      }),
    }),
  }),
});

export const { useGetPaymentQuery, useAddPaymentMutation } = paymentService;
