import { createApi } from "@reduxjs/toolkit/query/react";
import baseQueryWithReauth from "./baseQuery";
import { ENDPOINT_CONSTANTS } from "../Constants/apiConstants";

export const locationService = createApi({
  reducerPath: "locationService",
  baseQuery: baseQueryWithReauth,
  endpoints: (builder) => ({
    getLocation: builder.query({
      query: () => ({
        url: ENDPOINT_CONSTANTS.GET_LOCATIONS,
        method: "GET",
      }),
    }),
    addLocation: builder.mutation({
      query: builder.query({
        query: (payload) => ({
          url: ENDPOINT_CONSTANTS.ADD_LOCATIONS,
          method: "POST",
          body: payload,
        }),
      }),
    }),
  }),
});

export const { useGetLocationQuery, useAddLocationMutation } = locationService;
