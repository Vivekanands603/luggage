import { createApi } from "@reduxjs/toolkit/query/react";
import baseQueryWithReauth from "./baseQuery";
import { ENDPOINT_CONSTANTS } from "../Constants/apiConstants";

export const userService = createApi({
  reducerPath: "userService",
  baseQuery: baseQueryWithReauth,
  endpoints: (builder) => ({
    register: builder.mutation({
      query: (body) => ({
        url: ENDPOINT_CONSTANTS.REGISTER,
        method: "POST",
        body,
      }),
    }),
    login: builder.mutation({
      query: (body) => ({
        url: ENDPOINT_CONSTANTS.LOGIN,
        method: "POST",
        body,
      }),
    }),
  }),
});

export const { useRegisterMutation, useLoginMutation } = userService;
