import { createApi } from "@reduxjs/toolkit/query/react";
import baseQueryWithReauth from "./baseQuery";
import { ENDPOINT_CONSTANTS } from "../Constants/apiConstants";

export const mainService = createApi({
  reducerPath: "mainService",
  baseQuery: baseQueryWithReauth,
  endpoints: (builder) => ({
    addMain: builder.mutation({
      query: (payload) => ({
        url: ENDPOINT_CONSTANTS.ADD_LUGGAGE,
        method: "POST",
        body: payload,
      }),
    }),
    updateMain: builder.mutation({
      query: ({ id, ...payload }) => {
        return {
          url: `${ENDPOINT_CONSTANTS.UPDATE_LUGGAGE}/${id}`,
          method: "PUT",
          body: payload,
        };
      },
    }),
    deleteMain: builder.mutation({
      query: (id) => {
        return {
          url: `${ENDPOINT_CONSTANTS.DELETE_LUGGAGE}/${id}`,
          method: "DELETE",
        };
      },
    }),
    getMain: builder.query({
      query: () => ({
        url: ENDPOINT_CONSTANTS.GET_LUGGAGE,
        method: "GET",
      }),
    }),
  }),
});

export const {
  useGetMainQuery,
  useAddMainMutation,
  useUpdateMainMutation,
  useDeleteMainMutation,
} = mainService;
