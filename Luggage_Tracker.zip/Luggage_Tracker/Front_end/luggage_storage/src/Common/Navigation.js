import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { ROUTE_CONSTANTS } from "../Constants/routeConstants";
import { Avatar, Menu, Dropdown, Tooltip } from "antd";
import { UserOutlined } from "@ant-design/icons";

function Navigation({ formData }) {
  const isAuthenticated = true;
  const storedUser = JSON.parse(localStorage.getItem("user"));
  const firstLetter = storedUser
    ? storedUser?.username.charAt(0).toUpperCase()
    : "";
  const Navigate = useNavigate();

  const handleSignout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    Navigate(ROUTE_CONSTANTS.LOGIN);
  };

  const menu = (
    <Menu>
      <div>
        <div className="mt-2 text-center">
          {storedUser ? (
            <Tooltip title={storedUser.username}>
              <Avatar className="mb-2">{firstLetter}</Avatar>
            </Tooltip>
          ) : (
            <Avatar icon={<UserOutlined />} />
          )}
        </div>
      </div>
      {isAuthenticated && (
        <>
          <Menu.Item onClick={handleSignout}>Sign Out</Menu.Item>
        </>
      )}
    </Menu>
  );

  return (
    <nav className="bg-orange-500 p-4 flex justify-end items-center transition-all">
      <div className="flex items-center justify-end">
        <Link
          to={ROUTE_CONSTANTS.HOME}
          state={{ formData }}
          className="text-white   hover:bg-white hover:text-orange-500 rounded  mr-4 transition-all"
        >
          Home
        </Link>
        <Link
          to={ROUTE_CONSTANTS.LUGGAGE}
          className="text-white hover:bg-white hover:text-orange-500 mr-4 rounded  transition-all"
        >
          Book
        </Link>
        <Link
          to={ROUTE_CONSTANTS.PAYMENT}
          className="text-white hover:bg-white hover:text-orange-500 mr-4 rounded  transition-all"
        >
          Payment
        </Link>
        <Link
          className="text-white hover:bg-white hover:text-orange-500 mr-4 rounded  transition-all"
          to={ROUTE_CONSTANTS.ORDERS}
        >
          My Orders
        </Link>
        {isAuthenticated && (
          <div className="flex items-center">
            <Dropdown
              overlay={menu}
              placement="bottomRight"
              trigger={["click"]}
            >
              <Avatar icon={<UserOutlined />} />
            </Dropdown>
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navigation;
