import React, { useState } from "react";
import { Spin, message } from "antd";
import { ROUTE_CONSTANTS } from "../../Constants/routeConstants";
import { useLocation, useNavigate } from "react-router-dom";
import Navigation from "../../Common/Navigation";
import { useAddPaymentMutation } from "../../Service/paymentService";

function Payment() {
  const [addPayment] = useAddPaymentMutation();
  var amount = 0;
  const location = useLocation();
  const formPayload = location.state ? location.state.formPayload : null;
  console.log("formPayload", formPayload);
  function result() {
    amount = formPayload.bag * 110;
    return amount;
  }
  const handlebutton = () => {
    setLoading(true);
    const formData = {
      bill: amount,
      ...formPayload,
    };
    setTimeout(() => {
      setLoading(false);
      navigate(ROUTE_CONSTANTS.HOME);
      message.success("Your payment is done!");
    }, 2000);
    console.log("formdata", formData);
    addPayment(formData).then((res) => console.log("res", res));
  };
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  return (
    <div>
      <div className="sticky top-0 z-50">
        <Navigation formData={formPayload} />
      </div>
      <div
        className="flex items-center justify-center  bg-cover bg-center"
        style={{
          backgroundImage: `url(${"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.123rf.com%2Fphoto_68221978_payment-terminal-with-card-on-white-background-top-view.html&psig=AOvVaw2iE3mKi41aH9Z8JpSKV9vl&ust=1704438919475000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCLDqmKOYw4MDFQAAAAAdAAAAABAS"})`,
        }}
      >
        <div className=" mt-8 bg-white w-1/2 h-auto  text-center">
          <div>
            <h1 className="mt-2 text-2xl font-bold text-orange-500">PAYMENT</h1>
            <div className=" w-full bg-white border border-gray-600 mt-6 p-4">
              <div className="flex flex-row ">
                <div className="flex flex-col">
                  <div className="text-orange-500 text-xl font-bold">
                    Status
                  </div>
                  <div className="text-gray-500 my-2">
                    <p>You Booked a Slot on {formPayload.drop_in}</p>
                  </div>
                </div>
                <div className="ml-auto flex flex-col items-center ">
                  <div className="text-orange-500 text-xl font-bold">
                    Bag Count
                  </div>
                  <div className=" my-2 text-gray-500">
                    Total Bag Count: {formPayload.bag}
                  </div>
                  <div className="my-2 text-gray-500">Taxes: 5%</div>
                  <div className="text-gray-500 my-2">Bill : {result()} </div>
                  <div className="h-8 w-20 bg-orange-500 text-white font-bold text-xl">
                    <Spin
                      spinning={loading}
                      tip="Hang on your action in processing..."
                    >
                      <button onClick={handlebutton}>Pay</button>
                    </Spin>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Payment;
