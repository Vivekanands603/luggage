import React, { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { ROUTE_CONSTANTS } from "../../Constants/routeConstants";

function LandingPage() {
  const auth = false;
  const navigate = useNavigate();
  useEffect(() => {
    auth ? navigate(ROUTE_CONSTANTS.HOME) : navigate(ROUTE_CONSTANTS.LOGIN);
  }, []);
  return <Outlet />;
}

export default LandingPage;
