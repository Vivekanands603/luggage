import React, { useState } from "react";
import Navigation from "../../Common/Navigation";
import { useLocation, useNavigate } from "react-router-dom";
import { useAddMainMutation } from "../../Service/mainService";
import { ROUTE_CONSTANTS } from "../../Constants/routeConstants";

function Luggage() {
  const location = useLocation();
  const [addMain] = useAddMainMutation();
  const [name, setName] = useState(null);
  const [coupon, setCoupon] = useState(null);
  const [email, setEmail] = useState(null);
  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const Navigate = useNavigate();
  const formData = location.state ? location.state.formData : null;
  const [form, setForm] = useState(formData);
  console.log(formData, "formdata");
  console.log(formData?.location, "formluggage");
  const handleButton = () => {
    let isValid = true;
    if (!name) {
      setNameError("Please enter your name");
      isValid = false;
    } else {
      setNameError("");
    }

    if (!email) {
      setEmailError("Please enter your email");
      isValid = false;
    } else {
      setEmailError("");
    }

    if (isValid) {
      const formPayload = {
        name,
        email,
        coupon,
        location: form?.location,
        ...form,
      };
      console.log("formPay", formPayload);
      addMain(formPayload)
        .then((Response) => {
          console.log("Booking Succesfull", Response);
          Navigate(ROUTE_CONSTANTS.PAYMENT, {
            state: { formPayload: formPayload },
          });
          setForm({
            location: formData?.location,
            bag: formData?.bag,
            drop_in: formData?.drop_in,
            from: formData?.from,
            drop_off: formData?.drop_off,
            to: formData?.to,
          });
          console.log("helloo");
          console.log("hiii");
        })
        .catch((error) => {
          console.log("Booking Failed", error);
        });
    }
  };

  return (
    <div>
      <div className="sticky top-0 z-50">
        <Navigation formData={formData} />
      </div>
      <div
        className="flex items-center justify-center  bg-cover bg-center"
        style={{
          backgroundImage: `url(${"https://twomonkeystravelgroup.com/wp-content/uploads/2021/04/London-Luggage-Storage-Guide-What-You-Should-Know-scaled.jpg"})`,
        }}
      >
        <div className=" mt-8 bg-white w-1/2 h-auto rounded-lg text-center">
          <div>
            <h1 className="mt-2 text-2xl font-bold text-orange-500">
              BOOKING FORM
            </h1>
          </div>
          <form className="mt-4 p-4">
            <div className="flex flex-col mb-4">
              <div className="flex flex-col items-start">
                <label
                  htmlFor="location "
                  className="text-orange-500 text-xl font-bold items-start"
                >
                  Location
                </label>

                <input
                  className="w-full p-2 border"
                  value={formData?.location}
                />
              </div>
              <div className="mt-4 flex flex-col items-start">
                <label
                  htmlFor="bags"
                  className="text-orange-500 text-xl font-bold"
                >
                  Bag#
                </label>
                <input
                  inputMode="select"
                  type="number"
                  id="bags"
                  name="bags"
                  className="w-full p-2 border"
                  min="0"
                  value={formData?.bag}
                />
              </div>
            </div>

            <div className="flex flex-col mb-4">
              <div className="w-full ">
                <div className="flex items-center">
                  <div className=" flex flex-col w-full  items-start">
                    <label
                      htmlFor="dropIn"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Drop In
                    </label>
                    <input
                      id="dropInDate"
                      name="dropInDate"
                      className="w-full p-2 border"
                      value={formData?.drop_in}
                    />
                  </div>
                  <div className="flex flex-col items-start">
                    <label
                      htmlFor="dropInTime"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Time
                    </label>
                    <input
                      id="dropInTime"
                      name="dropInTime"
                      className="w-full p-2 border"
                      value={formData?.from}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div>
              <div className="w-full ">
                <div className="flex items-center">
                  <div className=" flex flex-col w-full  items-start">
                    <label
                      htmlFor="dropIn"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Drop Off
                    </label>
                    <input
                      id="dropInDate"
                      name="dropInDate"
                      className="w-full p-2 border"
                      value={formData?.drop_off}
                    />
                  </div>
                  <div className="flex flex-col items-start">
                    <label
                      htmlFor="dropInTime"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Time
                    </label>
                    <input
                      id="dropInTime"
                      name="dropInTime"
                      className="w-full p-2 border"
                      value={formData?.to}
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-start mt-4">
                <label
                  htmlFor="name"
                  className="text-orange-500 text-xl font-bold"
                >
                  Name
                </label>
                <input
                  type="text"
                  className="w-full p-2 border"
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              {nameError && <p className="text-red-500">{nameError}</p>}
              <div className="flex flex-col items-start mt-4">
                <label
                  htmlFor="email"
                  className="text-orange-500 text-xl font-bold"
                >
                  Email
                </label>
                <input
                  type="text"
                  className="w-full p-2 border"
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              {emailError && <p className="text-red-500">{emailError}</p>}
              <div className="flex flex-col items-start mt-4">
                <label
                  htmlFor="coupon"
                  className="text-orange-500 text-xl font-bold"
                >
                  Coupon
                </label>
                <input
                  type="text"
                  placeholder="if you have coupon, enter it"
                  className="w-full p-2 border"
                  onChange={(e) => setCoupon(e.target.value)}
                />
              </div>
            </div>
            <div className="mt-6 text-center">
              <button
                type="button"
                className="bg-orange-500 text-white text-2xl py-2 px-4 rounded"
                onClick={handleButton}
              >
                Book
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Luggage;
