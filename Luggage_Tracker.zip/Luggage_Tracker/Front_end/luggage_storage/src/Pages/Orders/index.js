import React from "react";
import Navigation from "../../Common/Navigation";

function index() {
  return (
    <div>
      <div className="sticky top-0 z-50">
        <Navigation />
      </div>
    </div>
  );
}

export default index;
