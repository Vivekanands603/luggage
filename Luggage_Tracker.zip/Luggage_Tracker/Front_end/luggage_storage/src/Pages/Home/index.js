import { React, useEffect, useMemo, useState } from "react";
import Navigation from "../../Common/Navigation";
import { DatePicker, TimePicker } from "antd";
import { AutoComplete } from "antd";
import { useGetLocationQuery } from "../../Service/locationService";
import { ROUTE_CONSTANTS } from "../../Constants/routeConstants";
import { useLocation, useNavigate } from "react-router-dom";
import { Spin } from "antd";
import moment from "moment";

function Home() {
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    location: "",
    bag: 0,
    drop_in: "",
    from: "",
    drop_off: "",
    to: "",
  });
  const location = useLocation();

  useEffect(() => {
    const form = location.state?.formData;
    console.log(form, "form");
    if (form) {
      console.log(123);
      setFormData(form);
    } else {
      setFormData({
        location: "",
        bag: 0,
        drop_in: "",
        from: "",
        drop_off: "",
        to: "",
      });
    }
  }, []);

  console.log(formData.location, "fd");

  const { data: locations } = useGetLocationQuery();
  const navigate = useNavigate();
  const data = useMemo(() => {
    const locationList = [];
    if (Array.isArray(locations)) {
      locations.forEach((loc) => {
        const city = loc?.location[0]?.name;
        const areas = loc?.location[0].areas
          ?.map((data) => data?.name)
          .filter(Boolean);
        if (city && areas.length > 0) {
          locationList.push(...areas.map((area) => `${city}-${area}`));
        }
      });
    }
    return locationList;
  }, [locations]);

  console.log(data, "data");
  const filteredOptions = data.filter((entry) =>
    entry.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDropInDateChange = (date, dateString) => {
    console.log("Selected Drop In Date:", dateString);
    setFormData((prev) => ({ ...prev, drop_in: dateString }));
  };

  const handleDropInTimeChange = (time, timeString) => {
    setFormData((prev) => ({ ...prev, from: timeString }));
  };
  const handleDropOffDateChange = (date, dateString) => {
    console.log("Selected Drop In Date:", dateString);
    setFormData((prev) => ({ ...prev, drop_off: dateString }));
  };
  const handleLocationChange = (value) => {
    setFormData((prev) => ({ ...prev, location: value }));
  };
  const handleDropOffTimeChange = (time, timeString) => {
    setFormData((prev) => ({ ...prev, to: timeString }));
  };
  const handleBagChange = (value) => {
    setFormData((prev) => ({ ...prev, bag: value }));
  };
  const [loading, setLoading] = useState(false);
  const handleSearch = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate(ROUTE_CONSTANTS.LUGGAGE, {
        state: { formData: formData },
      });
    }, 1000);
    console.log("form data", formData);
  };
  console.log("form data", formData);

  console.log(moment(formData.drop_off).format("YYYY-MM-DD"), "dayaa");

  return (
    <div>
      <div className="sticky top-0 z-50">
        <Navigation />
      </div>
      <div
        className="flex items-center justify-center bg-cover bg-center h-screen"
        style={{
          backgroundImage: `url(${"https://imgcap.capturetheatlas.com/wp-content/uploads/2022/09/Consigna-de-equipaje-1415x540-1663878329.jpg"})`,
        }}
      >
        <div className="mt-12 bg-white w-2/3 h-2/3 rounded-lg text-center">
          <div>
            <h1 className="mt-2 text-2xl font-bold text-orange-500">
              CHECK AVAILABILITY
            </h1>
          </div>
          <form className="mt-4 p-4">
            <div className="flex justify-between mb-4">
              <div className="flex flex-col w-1/2 pr-2 items-start">
                <label
                  htmlFor="location "
                  className="text-orange-500 text-xl font-bold"
                >
                  Location
                </label>
                <AutoComplete
                  value={formData.location ? formData.location : searchTerm}
                  onChange={(value) => setSearchTerm(value)}
                  dataSource={filteredOptions}
                  onSelect={handleLocationChange}
                  className="w-full "
                >
                  <input
                    value={formData ? formData.location : searchTerm}
                    className="w-full p-2 border"
                  />
                </AutoComplete>
              </div>
              <div className="flex flex-col w-1/2 pl-2 items-start">
                <label
                  htmlFor="bags"
                  className="text-orange-500 text-xl font-bold"
                >
                  Bag#
                </label>
                <input
                  inputMode="select"
                  type="number"
                  id="bags"
                  value={formData.bag}
                  name="bag"
                  className="w-full p-2 border"
                  min="0"
                  onChange={(e) => handleBagChange(e.target.value)}
                />
              </div>
            </div>

            <div className="flex justify-between mb-4">
              <div className="w-full pr-2">
                <div className="flex items-center">
                  <div className="pr-2 w-full flex flex-col items-start">
                    <label
                      htmlFor="dropIn"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Drop In
                    </label>
                    <DatePicker
                      id="dropInDate"
                      name="drop_in"
                      value={formData.drop_in ? moment(formData.drop_in) : null}
                      className="w-full p-2 border"
                      onChange={handleDropInDateChange}
                    />
                  </div>
                  <div className="flex flex-col items-start">
                    <label
                      htmlFor="dropInTime"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Time
                    </label>
                    <TimePicker
                      id="dropInTime"
                      value={
                        formData.from ? moment(formData.from, "HH:mm:ss") : null
                      }
                      name="from"
                      className="w-full p-2 border"
                      onChange={handleDropInTimeChange}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-between mb-4">
              <div className="w-full pr-2">
                <div className="flex items-center">
                  <div className="pr-2 w-full flex flex-col items-start">
                    <label
                      htmlFor="dropIn"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Drop Off
                    </label>
                    <DatePicker
                      id="dropInDate"
                      name="drop_off"
                      value={
                        formData.drop_off ? moment(formData.drop_off) : null
                      }
                      className="w-full p-2 border"
                      onChange={handleDropOffDateChange}
                    />
                  </div>
                  <div className="flex flex-col items-start">
                    <label
                      htmlFor="dropInTime"
                      className="text-orange-500 text-xl font-bold"
                    >
                      Time
                    </label>
                    <TimePicker
                      id="dropInTime"
                      value={
                        formData.to ? moment(formData.to, "HH:mm:ss") : null
                      }
                      name="to"
                      className="w-full p-2 border"
                      onChange={handleDropOffTimeChange}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="text-center">
              <Spin spinning={loading} tip="Searching...">
                <button
                  type="button"
                  className="bg-orange-500 text-white text-2xl py-2 px-4 rounded"
                  onClick={handleSearch}
                >
                  search
                </button>
              </Spin>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Home;
