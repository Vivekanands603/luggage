import React, { useState } from "react";
import Signin from "./Signin";
import Signup from "./Signup";

function Login() {
  const [signinVisible, setSigninVisible] = useState(true);
  const [signupVisible, setSignupVisible] = useState(false);

  const showSignin = () => {
    setSigninVisible(true);
    setSignupVisible(false);
  };

  const showSignup = () => {
    setSigninVisible(false);
    setSignupVisible(true);
  };

  return (
    <div className="flex h-screen">
      <div
        className="w-2/3 bg-cover bg-center"
        style={{
          backgroundImage:
            'url("https://wallpaperaccess.com/full/9841036.jpg")',
        }}
      ></div>
      <div className="w-1/3 p-8">
        {signinVisible && <Signin onToggle={showSignup} />}
        {signupVisible && <Signup onToggle={showSignin} />}
      </div>
    </div>
  );
}

export default Login;
