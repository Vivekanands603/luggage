import React from "react";
import { Form, Input, Button, Checkbox, message } from "antd";
import { useLoginMutation } from "../../Service/userService";
import { useNavigate } from "react-router-dom";
import { ROUTE_CONSTANTS } from "../../Constants/routeConstants";
import { setLocalStorage } from "../../utils";

const Signin = ({ onToggle }) => {
  const [login, { isLoading, isError }] = useLoginMutation();
  const Navigate = useNavigate();
  const onFinish = (values) => {
    const { username, password } = values;
    login({ username, password })
      .unwrap()
      .then((res) => {
        const { token, ...user } = res;
        setLocalStorage("token", token);
        setLocalStorage("user", user);
        message.success(`Welcome ${username}!!`);
        console.log("Login successful!");
        Navigate(ROUTE_CONSTANTS.HOME);
      })
      .catch((err) => {
        console.log(err, "err");
        message.error(err?.data.message);
      });
  };

  return (
    <div className="my-10">
      <h2 className="text-center text-xl font-bold text-black mb-4">Sign in</h2>
      <Form
        name="signin-form"
        onFinish={onFinish}
        className="w-full max-w-sm mx-auto"
      >
        <Form.Item
          name="username"
          rules={[{ required: true, message: "Please input your username!" }]}
        >
          <Input placeholder="Username" className="w-full p-2 border rounded" />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[{ required: true, message: "Please input your password!" }]}
        >
          <Input.Password
            placeholder="Password"
            className="w-full p-2 border rounded"
          />
        </Form.Item>

        <Form.Item name="remember" valuePropName="checked">
          <Checkbox className="text-black">Remember me</Checkbox>
        </Form.Item>

        <Form.Item>
          <Button
            type="primary"
            htmlType="submit"
            className="w-full bg-blue-500 hover:bg-blue-700"
            loading={isLoading}
          >
            Signin
          </Button>
        </Form.Item>
      </Form>

      <p className="text-black text-center">
        Don't have an account?{" "}
        <span onClick={onToggle} className="cursor-pointer text-blue-500">
          Sign up here
        </span>
      </p>

      {isError && (
        <p className="text-red-500 text-center">
          Login failed. Please check your credentials.
        </p>
      )}
    </div>
  );
};

export default Signin;
