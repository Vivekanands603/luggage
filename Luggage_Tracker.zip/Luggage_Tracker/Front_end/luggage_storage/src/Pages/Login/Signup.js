import React, { useState } from "react";
import { Form, Input, Button } from "antd";
import { useRegisterMutation } from "../../Service/userService";

const Signup = ({ onToggle }) => {
  const [errMsg, setErrMsg] = useState(null);
  const [Register] = useRegisterMutation();
  const onFinish = (values) => {
    Register(values)
      .unwrap()
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
        setErrMsg(err?.data.message);
      });
  };

  return (
    <div className="my-10">
      <h2 className="text-center text-xl font-bold text-gray mb-4">Sign up</h2>
      <Form name="signup-form" onFinish={onFinish}>
        <Form.Item
          name="username"
          rules={[{ required: true, message: "Please input your username!" }]}
        >
          <Input placeholder="Username" className="w-full p-2 border rounded" />
        </Form.Item>

        <Form.Item
          name="password"
          rules={[{ required: true, message: "Please input your password!" }]}
        >
          <Input.Password
            placeholder="Password"
            className="w-full p-2 border rounded"
          />
        </Form.Item>

        <Form.Item
          name="confirmPassword"
          dependencies={["password"]}
          rules={[
            { required: true, message: "Please confirm your password!" },
            ({ getFieldValue }) => ({
              validator(_, value) {
                if (!value || getFieldValue("password") === value) {
                  return Promise.resolve();
                }
                return Promise.reject(
                  new Error("The two passwords do not match!")
                );
              },
            }),
          ]}
        >
          <Input.Password
            placeholder="Confirm Password"
            className="w-full p-2 border rounded"
          />
        </Form.Item>

        <Form.Item>
          <Button
            className="w-full bg-blue-500 hover:bg-blue-700"
            htmlType="submit"
            type="primary"
          >
            Sign up
          </Button>
        </Form.Item>
      </Form>

      <p>
        Already have an account?{" "}
        <span onClick={onToggle} style={{ cursor: "pointer", color: "blue" }}>
          Sign in here
        </span>
      </p>
      {errMsg && <p className="text-red-500 text-center">{errMsg}</p>}
    </div>
  );
};

export default Signup;
