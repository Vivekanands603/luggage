const mongoose = require("mongoose");

const areaSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
});

const locationSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  areas: [areaSchema],
});

const mainSchema = new mongoose.Schema({
  location: [locationSchema],
});

module.exports = mongoose.model("locations", mainSchema);
