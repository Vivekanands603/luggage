const mongoose = require("mongoose");
const { Schema } = mongoose;

const paymentSchema = new mongoose.Schema({
  main: {
    type: Schema.Types.ObjectId,
    ref: "Main",
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  bill: {
    type: Number,
    req: true,
  },
});

const Payment = mongoose.model("Payment", paymentSchema);
module.exports = Payment;
