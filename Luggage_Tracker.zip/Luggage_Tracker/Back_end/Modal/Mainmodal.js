const mongoose = require("mongoose");

const mainSchema = new mongoose.Schema({
  uniqueId: {
    type: mongoose.Schema.ObjectId,
  },
  location: {
    type: String,
    required: true,
  },
  bag: {
    type: Number,
    required: true,
  },
  drop_in: {
    type: String,
    required: true,
  },
  drop_off: {
    type: String,
    required: true,
  },
  from: {
    type: String,
    required: true,
  },
  to: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  coupon: {
    type: String,
  },
});

const Main = mongoose.model("main", mainSchema);

module.exports = Main;
