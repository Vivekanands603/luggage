const Main = require("../Modal/Locationmodal");

const addLocation = async (req, res) => {
  try {
    const { LocationName, areas } = req.body;

    if (!LocationName) {
      return res.status(400).json({ error: "LocationName is required" });
    }

    let mainDoc = await Main.findOne({ "location.name": LocationName });

    if (!mainDoc) {
      mainDoc = new Main();
    }

    mainDoc.location.push({
      name: LocationName,
      areas: areas?.map((area) => ({ name: area })),
    });

    await mainDoc.save();
    res.status(201).json({ message: "Location added" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error.message });
  }
};

const getAllLocations = async (req, res) => {
  try {
    const mainDoc = await Main.find();
    console.log(mainDoc, "mainDoc");

    if (!mainDoc) {
      return res.status(404).json({ message: "No locations found" });
    }

    res.json(mainDoc);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
};

module.exports = { addLocation, getAllLocations };
