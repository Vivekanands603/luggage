const Payment = require("../Modal/Payment");

const postPayments = async (req, res) => {
  try {
    const { main, bill, user } = req.body;
    const newPayment = new Payment({
      main,
      bill,
      user,
    });
    await newPayment.save();
    res
      .status(201)
      .json({ message: "Payment Created Successfully", payment: newPayment });
  } catch (error) {
    console.log(error, "error");
    res.status(500).json({ error: "Internal Server Error" });
  }
};

const getPaymentsCountByUser = async (req, res) => {
  try {
    const payments = await Payment.find({}).populate("main").populate("user");
    res.json(payments);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = { getPaymentsCountByUser, postPayments };
