const User = require("../Modal/Usermodal");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const register = async (req, res) => {
  try {
    const { username, password } = req.body;
    const isAdmin = req.body.isAdmin || false;

    const existingUser = await User.findOne({ username });

    if (existingUser) {
      return res.status(500).json({ message: "Username already exists" });
    }

    const user = new User({ username, password, isAdmin });
    await user.save();

    res.status(201).json({ message: "User Registered Successfully" });
  } catch (error) {
    console.log(error, "error");
    res.status(500).json({ message: error.message });
  }
};

const login = async (req, res) => {
  try {
    const { username } = req.body;
    console.log(req.body);
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(500).json({ message: "User Not Found" });
    }
    const isPasswordValid = await bcrypt.compare(
      req.body.password,
      user.password
    );

    if (isPasswordValid) {
      const token = jwt.sign({ userId: user._id }, process.env.SECRET_KEY, {
        expiresIn: "1h",
      });
      const { password, ...userDetails } = user._doc;
      res.status(200).json({ ...userDetails, token });
    } else {
      return res.status(500).json({ message: "Password is not correct" });
    }
  } catch (error) {
    console.log(error);
    return res.status(500).json({ error: error.message });
  }
};

module.exports = { register, login };
