const Main = require("../Modal/Mainmodal");
const { ObjectId } = require("mongodb");

const createMain = async (req, res) => {
  console.log(req.body, "body");
  try {
    const {
      uniqueId,
      bag,
      drop_in,
      drop_off,
      from,
      to,
      email,
      name,
      coupon,
      location,
    } = req.body;
    const MainEntry = new Main({
      uniqueId,
      bag,
      location,
      drop_in,
      drop_off,
      from,
      to,
      email,
      name,
      coupon,
    });
    // const userId = req.user._id;
    // console.log("userid", userId);
    await MainEntry.save();
    res.status(201).json({ message: "Main entry created successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error.message });
  }
};

const getMain = async (req, res) => {
  const id = new ObjectId(req.params.id);
  const luggage = await Main.aggregate([
    {
      $match: {
        uniqueId: id,
      },
    },
    {
      $project: {
        _id: 1,
        bag: 1,
        drop_in: 1,
        drop_off: 1,
        from: 1,
        to: 1,
        name: 1,
        email: 1,
        location: 1,
      },
    },
    {
      $group: {
        _id: id,
        data: { $push: "$ROOT" },
      },
    },
  ]);
  res.status(200).json(luggage);
};

const editMain = async (req, res) => {
  try {
    const { id } = req.params;
    const existingEntry = await Main.findByIdAndUpdate(
      id,
      {
        $set: req.body,
      },
      {
        new: true,
      }
    );
    console.log(existingEntry, "updated");
    res.json({ message: "Main entry updated successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error.message });
  }
};

const deleteMain = async (req, res) => {
  try {
    const { id } = req.params;
    const existingEntry = await Main.findByIdAndDelete(id);
    if (!existingEntry) {
      return res.status(404).json({ error: "Main entry not found" });
    }
    res.json({ message: "Main entry deleted successfully" });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: error.message });
  }
};

module.exports = { createMain, getMain, editMain, deleteMain };
