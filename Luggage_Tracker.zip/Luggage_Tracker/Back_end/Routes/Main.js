const express = require("express");
const MainController = require("../Controller/MainController");

const router = express.Router();

router.post("/", MainController.createMain);
router.get("/:id", MainController.getMain);
router.put("/:id", MainController.editMain);
router.delete("/:id", MainController.deleteMain);

module.exports = router;
