const express = require("express");
const paymentController = require("../Controller/paymentController");

const router = express.Router();

router.get("/", paymentController.getPaymentsCountByUser);
router.post("/", paymentController.postPayments);

module.exports = router;
