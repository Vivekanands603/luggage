const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const authRouter = require("./Routes/User");
const locationRouter = require("./Routes/Location");
const mainRouter = require("./Routes/Main");
const paymentRouter = require("./Routes/Payment");
const app = express();
require("dotenv").config();
const port = process.env.PORT || 8000;
const mongoURI =
  process.env.MONGO_URI ||
  "mongodb+srv://vivek:9360895745@cluster0.kagdj8h.mongodb.net/Luggage_Tracker";
const secretKey = process.env.SECRET_KEY || "mysecretkey";

app.use(express.json());
app.use(cors());
app.options("*", cors());
app.use("/auth", authRouter);
app.use("/location", locationRouter);
app.use("/main", mainRouter);
app.use("/payment", paymentRouter);
mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
